import { AcademyIndex } from '@/components/academy/academy-index'

export const metadata = { title: 'Masterclass Academy' }

export default function AcademyPage() {
  return <AcademyIndex />
}
