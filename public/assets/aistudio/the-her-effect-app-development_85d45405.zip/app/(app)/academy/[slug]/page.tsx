import { ModuleView } from '@/components/academy/module-view'
import { MODULES, getModule } from '@/lib/content/academy'
import { notFound } from 'next/navigation'

export function generateStaticParams() {
  return MODULES.map((m) => ({ slug: m.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  return { title: getModule(slug)?.title ?? 'Module' }
}

export default async function ModulePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const mod = getModule(slug)
  if (!mod) notFound()
  return <ModuleView module={mod} />
}
