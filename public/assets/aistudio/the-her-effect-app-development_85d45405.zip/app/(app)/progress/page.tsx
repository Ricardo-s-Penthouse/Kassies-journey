import { ProgressView } from '@/components/progress/progress-view'

export const metadata = { title: 'Progress & Journal' }

export default function ProgressPage() {
  return <ProgressView />
}
