import { SettingsView } from '@/components/settings/settings-view'

export const metadata = { title: 'Profile & Settings' }

export default function SettingsPage() {
  return <SettingsView />
}
