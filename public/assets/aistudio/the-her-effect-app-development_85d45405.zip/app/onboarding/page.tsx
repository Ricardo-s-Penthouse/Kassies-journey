import { OnboardingWizard } from '@/components/onboarding/wizard'

export const metadata = { title: 'Welcome' }

export default function OnboardingPage() {
  return <OnboardingWizard />
}
